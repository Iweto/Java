package ITArcher;

import Archers.Archer;
import Archers.Mladshi;
import Archers.Starshi;
import Archers.Veteran;
import Bows.AluminumBow;
import Bows.CarbonBow;
import Demo.Demo;

import java.util.*;

public class ITArcher implements Comparable<Archer> {
    private String name;
    private String address;
    private String trainer;
    // archer -> score
    private TreeMap<Archer, Integer> archers;

    private HashMap<String, TreeMap<Integer, Archer>> book;

    public ITArcher(String name, String address, String trainer) {
        this.name = name;
        this.address = address;
        this.trainer = trainer;
        this.archers = new TreeMap<>();
        this.book = new HashMap<>();

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ITArcher itArcher = (ITArcher) o;
        return Objects.equals(name, itArcher.name) &&
                Objects.equals(address, itArcher.address) &&
                Objects.equals(trainer, itArcher.trainer);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, address, trainer);
    }

    public void addArcher(Archer archer) {
        archers.put(archer, 0);
    }

    private void printAllParticipants() {
        System.out.println(archers);
    }

    @Override
    public int compareTo(Archer o) {
        return this.name.compareTo(o.getName());
    }

    public void printBook() {
        for (Map.Entry<Archer, Integer> e : archers.entrySet()) {
            if (e.getKey() instanceof Mladshi) {
                if (!book.containsKey("Mladshi")) {
                    book.put("Mladshi", new TreeMap<>());
                    continue;
                }
                book.get("Mladshi").put(e.getValue(), e.getKey());
            } else if (e.getKey() instanceof Starshi) {
                if (!book.containsKey("Starshi")) {
                    book.put("Starshi", new TreeMap<>());
                    continue;
                }
                book.get("Starshi").put(e.getValue(), e.getKey());
            } else if (e.getKey() instanceof Veteran) {
                if (!book.containsKey("Veteran")) {
                    book.put("Veteran", new TreeMap<>());
                    continue;
                }
                book.get("Veteran").put(e.getValue(), e.getKey());
            }
        }

        for (Map.Entry<String,TreeMap<Integer,Archer>> e : book.entrySet()) {
            System.out.println("-----" + e.getKey() + "-----");
            for (Map.Entry<Integer,Archer> innerE : e.getValue().entrySet()) {
                System.out.println(innerE.getValue() + " " + innerE.getKey());
            }
        }
    }
        public void startTournament() {
            printAllParticipants();
            // increment number of competition on all archers
            for (Map.Entry<Archer, Integer> e : archers.entrySet()) {
                e.getKey().setNumberOfCompetition(e.getKey().getNumberOfCompetition() + 1);
            }

            for (Map.Entry<Archer, Integer> e : archers.entrySet()) {
                if (e.getKey() instanceof Mladshi) {
                    for (int i = 0; i < 30; i++) {
                        int chanceToMiss = Demo.randomNumber(1, 100);
                        if (chanceToMiss <= 10) {
                            continue;
                        }
                        int score = Demo.randomNumber(1, 10);
                        e.setValue(e.getValue() + score);
                    }
                } else {
                    for (int i = 0; i < 60; i++) {
                        if (e.getKey() instanceof Starshi) {
                            int chanceToMiss = Demo.randomNumber(1, 100);
                            if (chanceToMiss <= 5) {
                                continue;
                            }
                            int score = Demo.randomNumber(6, 10);

                            if (e.getKey().getBow().isStabilization() || e.getKey().getBow().isSight()) {
                                if (score < 10) {
                                    if (e.getKey().getBow() instanceof AluminumBow) {
                                        score++;
                                    }
                                    if (e.getKey().getBow() instanceof CarbonBow) {
                                        if (score >= 7) {
                                            score = 10;
                                        } else {
                                            score += 3;
                                        }
                                    }
                                }

                            }
                            e.setValue(e.getValue() + score);
                        } else {
                            int score = Demo.randomNumber(6, 10);
                            if (score >= 7) {
                                score = 10;
                            } else {
                                score += 3;
                            }
                            e.setValue(e.getValue() + score);

                        }
                    }
                }
            }

        }
}

