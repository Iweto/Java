package Archers;

import Bows.AluminumBow;
import Bows.Bow;
import Bows.CarbonBow;
import Demo.Demo;

public class Starshi extends Archer{

    public Starshi(String name, String gender, int age, Bow bow){
        super(name, gender, age, bow);
        this.experience = Demo.randomNumber(3,10);
    }

}
