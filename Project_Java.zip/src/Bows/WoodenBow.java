package Bows;

import Demo.Demo;

public class WoodenBow extends Bow{

    public WoodenBow(String manufacturer, double weight){
        super(manufacturer, weight);
        this.sight = false;
        this.stabilization = false;
        this.tensileStrength = Demo.randomNumber(20,30);
    }




}
