package Bows;

import Demo.Demo;

public class CarbonBow extends Bow {


    public CarbonBow(String manufacturer, double weight){
        super(manufacturer, weight);
        this.sight = true;
        this.stabilization = true;
        this.tensileStrength = Demo.randomNumber(28,40);
    }




}
