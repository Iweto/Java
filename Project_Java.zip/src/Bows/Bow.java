package Bows;

public abstract class Bow {
    private String manufacturer;
    private double weight;
    protected int tensileStrength;
    protected boolean sight;
    protected boolean stabilization;

    public Bow(String manufacturer, double weight){
        this.manufacturer = manufacturer;
        this.weight = weight;
    }

    @Override
    public String toString() {
        return " manifacturer: " + this.manufacturer +" weight: "+ this.weight + " tensile strength: " +
                this.tensileStrength + " sight: " + this.sight +" stabilization: "+this.stabilization;
    }

    public boolean isSight() {
        return sight;
    }

    public boolean isStabilization() {
        return stabilization;
    }
}
