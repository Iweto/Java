package Archers;

import Bows.Bow;
import Bows.WoodenBow;
import Demo.Demo;

public class Mladshi extends Archer{

    public Mladshi(String name, String gender, int age, Bow bow){
        super(name, gender, age, bow);
        this.experience = 1;
    }

}
