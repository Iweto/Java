package Archers;

import Bows.Bow;

public abstract class Archer {
    private String name;
    private String gender;
    private int age;
    protected Bow bow;
    protected double experience;
    private int numberOfCompetition;

    public Archer(String name, String gender, int age, Bow bow){
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.bow = bow;
        this.numberOfCompetition = 0;

    }

    public Bow getBow() {
        return bow;
    }

    @Override
    public String toString() {
        return "name: " + this.name + " gender: " +this.gender + "age: " + this.age + " ___BOW___" +
                this.bow + "experience: " + this.experience;
    }

    public String getName() {
        return name;
    }

    public int getNumberOfCompetition() {
        return numberOfCompetition;
    }

    public void setNumberOfCompetition(int numberOfCompetition) {
        this.numberOfCompetition = numberOfCompetition;
    }
}
