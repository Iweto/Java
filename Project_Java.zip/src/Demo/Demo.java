package Demo;

import Archers.Archer;
import Archers.Mladshi;
import Archers.Starshi;
import Archers.Veteran;
import Bows.AluminumBow;
import Bows.Bow;
import Bows.CarbonBow;
import Bows.WoodenBow;
import ITArcher.ITArcher;

import java.util.Random;

public class Demo {
    public static void main(String[] args) {

        ITArcher club = new ITArcher("IT ARCHER", "bul Goce Delchev 65", "bestArcher");

        for (int i = 0; i < 40; i++) {
            Archer ar;
            int chance = randomNumber(1,100);
            int age = randomNumber(12,52);
            if(chance <=50){ // male or female
                chance = randomNumber(1,100);
                if(chance <= 33){  //starshi
                    chance = randomNumber(0,100);
                    if(chance <= 50){
                        //aluminum bow
                        Bow bow = new AluminumBow("Manifacturer" + (i+1),Demo.randomNumber(1,3));
                        ar = new Starshi("Starshi" +(i+1), "male", age, bow );
                    }
                    else{
                        Bow bow = new CarbonBow("Manifacturer" + (i+1),Demo.randomNumber(1,3));
                        //Carbon bow
                        ar = new Starshi("Starshi" +(i+1), "male", age, bow);
                    }

                }
                else if(chance <= 66){    // mladshi
                    Bow bow = new WoodenBow("Manifacturer" + (i+1),Demo.randomNumber(1,3));
                    ar = new Mladshi("Mladshi" +(i+1), "male", age, bow);
                }
                else{ // veteran
                    Bow bow = new WoodenBow("Manifacturer" + (i+1),Demo.randomNumber(1,3));
                    ar = new Veteran("Veteran" +(i+1), "male", age, bow);
                }
            }
            else{
                chance = randomNumber(1,100);
                if(chance <= 33){  //starshi
                    chance = randomNumber(0,100);
                    if(chance <= 50){
                        //aluminum bow
                        Bow bow = new AluminumBow("Manifacturer" + (i+1),Demo.randomNumber(1,3));
                        ar = new Starshi("Starshi" +(i+1), "female", age, bow );
                    }
                    else{
                        Bow bow = new CarbonBow("Manifacturer" + (i+1),Demo.randomNumber(1,3));
                        //Carbon bow
                        ar = new Starshi("Starshi" +(i+1), "female", age, bow);
                    }

                }
                else if(chance <= 66){    // mladshi
                    Bow bow = new WoodenBow("Manifacturer" + (i+1),Demo.randomNumber(1,3));
                    ar = new Mladshi("Mladshi" +(i+1), "female", age, bow);
                }
                else{ // veteran
                    Bow bow = new CarbonBow("Manifacturer" + (i+1),Demo.randomNumber(1,3));
                    ar = new Veteran("Veteran" +(i+1), "female", age, bow);
                }

            }
            club.addArcher(ar);

        }

        club.startTournament();
        club.printBook();

    }

    public static int randomNumber(int min, int max){
        Random r = new Random();

        return r.nextInt(max-min+1) + min;
    }
}
