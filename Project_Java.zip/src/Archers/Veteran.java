package Archers;

import Bows.Bow;
import Demo.Demo;

public class Veteran extends Archer{

    public Veteran(String name, String gender, int age, Bow bow){
        super(name, gender, age, bow);
        this.experience = Demo.randomNumber(10,60);
    }


}
