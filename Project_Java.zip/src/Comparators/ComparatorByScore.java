package Comparators;

import Archers.Archer;

import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

public class ComparatorByScore implements Comparator<Map.Entry<Integer,Archer>> {

    @Override
    public int compare(Map.Entry<Integer, Archer> o1, Map.Entry<Integer, Archer> o2) {
        return o1.getKey() - o2.getKey();
    }
}
