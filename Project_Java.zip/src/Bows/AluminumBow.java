package Bows;

import Demo.Demo;

public class AluminumBow extends Bow {



    public AluminumBow(String manufacturer, double weight){
        super(manufacturer, weight);
        this.sight = true;
        this.stabilization = false;
        this.tensileStrength = Demo.randomNumber(25,40);
    }
}
